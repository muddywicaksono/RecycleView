package com.example.mydraft;

import java.util.ArrayList;

public class FootballData {
    private static String[] title = new String[]
            {"Real Madrid","AC Milan","PSG", "Bayern Munchen","Chelsea","Manchester United","Manchester City","Juventus","Liverpool","Dortmund"};
    private static int[] thumbnail = new int[]
            {R.drawable.madrid,R.drawable.acmilan,R.drawable.psg,R.drawable.bayern,R.drawable.cels,R.drawable.mu,R.drawable.mancity,R.drawable.juve,R.drawable.ipul,R.drawable.dortmund};
    public static ArrayList<FootballModel> getListData(){
        FootballModel footballModel = null;
        ArrayList<FootballModel> list = new ArrayList<>();
        for (int i = 0; i <title.length; i++){
            footballModel = new FootballModel();
            footballModel.setLambangTeam(thumbnail[i]);
            footballModel.setNamaTeam(title[i]);
            list.add(footballModel);
        }
        return list;
    }

}
