package com.example.mydraft;

public class FootballModel {
    private String namaTeam;
    private int lambangTeam;

    public int getLambangTeam() {
        return lambangTeam;
    }

    public void setLambangTeam(int lambangTeam) {
        this.lambangTeam = lambangTeam;
    }

    public String getNamaTeam() {
        return namaTeam;
    }

    public void setNamaTeam(String namaTeam) {
        this.namaTeam = namaTeam;
    }
}
